package com.lionos

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val user = findViewById<EditText>(R.id.userInput)
        val pass = findViewById<EditText>(R.id.passInput)
        val btn = findViewById<Button>(R.id.loginBtn)

        btn.setOnClickListener {
    val u = user.text.toString()
    val p = pass.text.toString()

    if (SessionManager.login(this, u, p)) {
        startActivity(Intent(this, SystemActivity::class.java))
        finish()
    } else {
        Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
    }
}