package com.lionos

import android.content.Context
import android.content.SharedPreferences

object SessionManager {

    private const val PREF_NAME = "lionos_prefs"
    private const val KEY_USER = "current_user"
    private const val KEY_PASS = "current_pass"

    private fun prefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    // 🧠 Login + guardar sesión
    fun login(context: Context, user: String, pass: String): Boolean {
        val storedUser = prefs(context).getString("user_$user", null)
        val storedPass = prefs(context).getString("pass_$user", null)

        return if (storedUser == user && storedPass == pass) {
            prefs(context).edit()
                .putString(KEY_USER, user)
                .putString(KEY_PASS, pass)
                .apply()
            true
        } else false
    }

    // 👤 Crear usuario nuevo
    fun register(context: Context, user: String, pass: String): Boolean {
        val prefs = prefs(context)

        if (prefs.contains("user_$user")) return false

        prefs.edit()
            .putString("user_$user", user)
            .putString("pass_$user", pass)
            .apply()

        return true
    }

    // 🔐 Usuario actual logeado
    fun getCurrentUser(context: Context): String? {
        return prefs(context).getString(KEY_USER, null)
    }

    // 🚪 Logout
    fun logout(context: Context) {
        prefs(context).edit()
            .remove(KEY_USER)
            .remove(KEY_PASS)
            .apply()
    }

    // ✔ Verificar sesión activa
    fun isLogged(context: Context): Boolean {
        return getCurrentUser(context) != null
    }
}