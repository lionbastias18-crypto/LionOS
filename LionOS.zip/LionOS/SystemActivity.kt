package com.lionos

import android.os.Bundle
import android.webkit.WebView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class SystemActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_system)

        val clock = findViewById<TextView>(R.id.clockText)

        // 🕒 reloj + fecha
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
        val time = sdf.format(Date())
        clock.text = "LionOS • $time"

        // 🌐 WebView motor (apps futuras)
        val web = findViewById<WebView>(R.id.webView)
        web.settings.javaScriptEnabled = true
        web.loadUrl("https://www.google.com")
    }
}