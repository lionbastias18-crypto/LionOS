package com.lionos

import android.webkit.WebView

object SystemCore {

    fun openApp(webView: WebView, appUrl: String) {
        webView.loadUrl(appUrl)
    }

    fun getUserRole(): String {
        return if (SessionManager.isAdmin()) "ADMIN" else "USER"
    }
}