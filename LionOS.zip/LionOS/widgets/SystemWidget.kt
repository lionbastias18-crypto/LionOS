package com.lionos.widgets

import java.text.SimpleDateFormat
import java.util.*

object SystemWidget {

    fun getFullTime(): String {
        val sdf = SimpleDateFormat("EEEE dd MMM yyyy - HH:mm:ss", Locale.getDefault())
        return sdf.format(Date())
    }
}